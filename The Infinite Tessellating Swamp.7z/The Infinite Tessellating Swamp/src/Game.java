import java.util.Scanner;

public class Game {
	
	

	public static void main(String[] args)
	{ 

		
		Board board = new Board(); 
		
		Player player = new Player("Player", "Magical compass"); 
		
		Treasure treasure = new Treasure(); 

		board.creatingBoard();

		treasure.createTreasure();

		Commands command = new Commands(); 
		
		command.runningGame();
	

		
		
		
	}

}
