
public class Board {

	private int posx = 10; 
	private int posy = 10; 
	
	
	static String [][] board = new String[8][8];
	
	public Board()
	{
		//creatingBoard(); 

	}
	
	public void creatingBoard()
	{
		for(int r = 0; r < board.length; r++)
		{
			for(int c = 0; c < board[0].length; c++)
			{
				board[r][c] = "x";	
			}
		}
	}
	
	public static void printBoard()
	{
		for(int r = 0; r < board.length; r++)
		{
			for(int c = 0; c < board[0].length; c++)
			{
				System.out.print(" " + board[r][c]);			
			}
			System.out.println("");
		}
	}
	
	
}
