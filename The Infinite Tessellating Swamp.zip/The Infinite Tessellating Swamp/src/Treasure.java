
public class Treasure extends Board {

	private int size; 
	private double col;
	private double row;
	
	public Treasure()
	{
		createTreasure();
		this.row = row; 
		this.col = col; 
	}
	
	public double getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public double getCol() {
		return col;
	}

	public void setCol(int col) {
		this.col = col;
	}

	public double getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public void createTreasure()
	{ 
			col = (int)(Math.random()*5) + 2;
			row = (int)(Math.random() * board[0].length);
//			System.out.println("treasure col:" + col);
//			System.out.println("treasure row:" + row);
			board[(int) row][(int) col] = "T";
			//Board.printBoard();
	}
}
