
public abstract class Character extends Board{

	private String name; 
	private String items; 
	
	public Character(String name, String items)
	{
		this.name = name; 
		this.items = items; 
	}

	public String getItems() {
		return items;
	}

	public void setItems(String items) {
		this.items = items;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
