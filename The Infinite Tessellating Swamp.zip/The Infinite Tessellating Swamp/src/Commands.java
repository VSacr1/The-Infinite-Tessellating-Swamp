import java.util.Scanner;

public class Commands {

	Player player = new Player("Player", "Magical Compass");
	Treasure treasure = new Treasure();
	Scanner sc = new Scanner(System.in);
	public int north;
	private boolean running = true;
	private String input;

	public Commands() {
		runningGame();
	}

	public void runningGame()
	{

			System.out.println("");
			System.out.println("Welcome to the Swamp");
			System.out.println(player.getName());
			System.out.println("");
			System.out.println("Aim is to find the treasure burried somewhere in the swamp");
			System.out.println("To help you have a " + player.getItems());
			System.out.println("");
			System.out.println("To move north press n. To move south press s");
			System.out.println("To move west press w. To move east press e");
			System.out.println("To activate compass press c");
			System.out.println("For help press h");
			System.out.println();

		sc.nextLine();
	
		while(running == true)
		{
			input = sc.nextLine();
			
			if(input.equals("N") || input.equals("n"))
			{
				player.getRow();
				
				player.setRow(player.getRow()+1);
				if(player.getRow() > 8)
				{
					player.setRow(player.getRow() - 9);
				}
				
			}
			
			
			else if(input.equals("S") || input.equals("s"))
			{
				player.getRow();
				
				player.setRow(player.getRow()-1);
				if(player.getRow() < 0)
				{
					player.setRow(player.getRow() + 9);
				}

			}
			
			else if(input.equals("W") || input.equals("w"))
			{
				player.getCol();
				
				player.setCol(player.getCol() + 1);
				
				if(player.getCol() > 8)
				{
					player.setCol(player.getCol() - 9);
				}

			}
			
			else if(input.equals("E") || input.equals("e"))
			{
				player.getCol();
				
				player.setCol(player.getCol() - 1);
				if(player.getCol() < 0)
				{
					player.setCol(player.getCol() + 9);
				}

			}
			
			else if(input.equals("C") || input.equals("c"))
			{
				int locationPlayer;
				locationPlayer = (int) ((int) Math.sqrt(player.getRow()) + Math.sqrt(player.getCol()));
				
				int locationTreasure; 
				locationTreasure = (int) ((int) Math.sqrt(treasure.getRow()) + Math.sqrt(treasure.getCol()));

				System.out.println("Help with finding Treasure Location: " + locationTreasure);
				System.out.println("Help with finding Treasure Location: " + locationPlayer);
				player.setItems(player.getMC());

			}
			
			else if(input.equals("H") || input.equals("h"))
			{
				System.out.println("Input N North, S South, E East, W West");
			}
			
			else
			{
				System.out.println("INVALID RESPONSE");
			}
			
			if(player.getCol() == treasure.getCol() && player.getRow() == treasure.getRow())
			{
				System.out.println("You have won!");
				System.out.println("You found the treasure and made it out safely");
				running = false;
				
			}
			
			System.out.println(player.getCol());
			System.out.println(player.getRow());
			
	
		}

	}
}
