
public class Player extends Character {
 
	private int size; 
	private double col;
	private double row;
	private String playerPosition;
	private int magicCompass;
	
	public Player(String name, String items)
	{
		super(name,items);
		createPlayer(); 
		
		this.row = row; 
		this.col = col; 
	}
	
	
	public double getCol() {
		return col;
	}

	public void setCol(double col) {
		this.col = col;
	}

	public double getRow() {
		return row;
	}

	public void setRow(double row) {
		this.row = row;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}
	
	public void createPlayer()
	{ 

			col = (int)(Math.random()*5) + 2;
			row = (int)(Math.random() * board[0].length);
//			System.out.println("player position col:" + col);
//			System.out.println("player position row:" + row);
			board[(int) row][(int) col] = "P";
			//Board.printBoard();

			
	}
	
	
	public void setItems(int items)
	{
		items = (int) Math.sqrt(Math.pow(row, col) + (int)Math.pow(col, row));
		System.out.println((int) Math.sqrt(Math.pow(row, col) + (int)Math.pow(col, row)));
		magicCompass = items; 
	}

	public int getMC()
	{
		return magicCompass;
	}


	public String getPlayerPosition() {
		return playerPosition;
	}


	public void setPlayerPosition(String playerPosition) {
		this.playerPosition = playerPosition;
	}
}
	
